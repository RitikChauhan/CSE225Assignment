package com.example.cse225_assignment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.tbuonomo.viewpagerdotsindicator.DotsIndicator;
import com.tbuonomo.viewpagerdotsindicator.SpringDotsIndicator;
import com.tbuonomo.viewpagerdotsindicator.WormDotsIndicator;

public class viewPager extends AppCompatActivity {
    ViewPager vp;
    DotsIndicator dot1;
    WormDotsIndicator dot3;
    SpringDotsIndicator dot2;
    ViewAdapter viewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_pager);

        vp = findViewById(R.id.vp);
        dot1 = findViewById(R.id.dot1);
        dot2 = findViewById(R.id.dot2);
        dot3 = findViewById(R.id.dot3);

        viewAdapter = new ViewAdapter(this);
        vp.setAdapter(viewAdapter);
        dot1.setViewPager(vp);
        dot2.setViewPager(vp);
        dot3.setViewPager(vp);
    }
}

